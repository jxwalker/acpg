# CEO brief, ACPG
One page summary.
