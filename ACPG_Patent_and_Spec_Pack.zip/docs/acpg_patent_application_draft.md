# Patent draft, ACPG
Claims and abstract with figure callouts.
