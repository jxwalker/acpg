# Architecture, ACPG
Control and data planes with compiler, checkers, prosecutors, adjudicator.
