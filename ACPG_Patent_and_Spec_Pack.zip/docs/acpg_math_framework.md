# Maths, ACPG
Coverage, violation severity, unresolved challenges, proof strength, confidence, composite scoring and hard gates.
