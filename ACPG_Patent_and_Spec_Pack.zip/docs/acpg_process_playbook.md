# Process playbook, ACPG MVP
Compliance fabric with generators, prosecutors, adjudicator, and proof bundles.
