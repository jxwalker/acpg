# Data model, ACPG
Policies, checks, challenges, adjudications, proofs, and provenance.
