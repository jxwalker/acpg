ACPG Patent Drawings - README

Files:
- figure_01_architecture.svg
- figure_02_policy_pipeline.svg
- figure_03_prosecutor_cluster.svg
- figure_04_adjudication_engine.svg
- figure_05_feedback_unit.svg
- figure_06_proof_bundle.svg
- figure_07_flowchart.svg
- figure_08_network_service.svg
- figure_09_proof_artefact.svg

Style:
- Black lines, no colour, sans-serif text, all-caps labels.
- Reference numerals are placed inside the upper-right of each box.
- Sized for 1200x800 px, scalable without loss.

USPTO/EPO Tips:
- Print to PDF at 300–600 DPI, black & white.
- Ensure line weight ≥ 0.2 mm and text height ≥ 3.2 mm on the printed page.
- Keep margins clear and include figure captions outside the claim set in the spec.
- If converting to TIFF for USPTO, use 1-bit, 300 DPI.

Edits:
- You may open the SVGs in Inkscape, Illustrator, or VS Code for minor adjustments.
- Please keep labels in UPPERCASE for clarity.
